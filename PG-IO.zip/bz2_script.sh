#!/bin/bash

#set -x
#trap read debug

str_date=20190101
end_date=20190625

#cd /home/iwf/WRF-install/WPS

current_date=$str_date
while [ $current_date -le $end_date ]; do
	mkdir /archive/@BZ2/Indian/$current_date
	tar --extract --verbose --file=./$current_date/Indian/ww3_data.tar.bz2 -C /archive/@BZ2/Indian/$current_date ./$current_date/Indian/tab44.ww3 --strip-components 3
	current_date=`date -d "$current_date 12:00 utc +1 day" +%Y%m%d`
done

echo "--> DONE! <--"

#!/bin/bash

dir=20160118
filecon=z.pgrb2full.0p50.f
filename=gfs.t00$filecon$time

for  time in {00..96..3}; do
	filename=gfs.t00$filecon$time
	wgrib2 ./$dir/$filename.grib2 -spread ./$dir/$time.txt
	cat ./$dir/$time.txt >> ./$dir/wind-gfs.dat
	echo ' '
done
exit 0

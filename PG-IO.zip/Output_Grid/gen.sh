#!/bin/bash


#ftpdir=/pub/data/nccf/com/gfs/prod
#server=ftp.ncep.noaa.gov
#today=`date +%Y%m%d`
today=20160131
dir=$today;
#hour=`date -u +%H`
#OK=$NULL

#date1=`sed -n 1p ./$dir/temp.txt`
date1=20160131
#date2=`date -d "$date1 +4 day" +%Y%m%d`
#date_res=`date -d "$date1 +1 day" +%Y%m%d`

echo "Creating Time Series Plots..."
cd ./Output_Grid
cp -fv ./ww3_outp.inp.ser ./ww3_outp.inp
sed -i "7 s:.*:   $date1 000000   3600   96:" ww3_outp.inp
ww3_outp

sl=6
rm -fv tab55.mod
for (( i = 1; i <= 96; i++ )); do

	sed -n "$sl","$(($sl+14))"p ./tab55.ww3 >> ./tab55.tmp
	sl=$(($sl+22))
done
echo ' '
echo ' '

awk '{ print $5}' tab55.tmp > gen.tmp

sl=1
for (( i = 1; i <= 96; i++ )); do
	echo " --> Processing Timestep $(($i-1))..."
	sed -n "$sl"p ./gen.tmp >> 23790.txt		#St.IV
	sed -n "$(($sl+1))"p ./gen.tmp >> 24149.txt	#Abumusa
	sed -n "$(($sl+2))"p ./gen.tmp >> 28287.txt	#Kish
	sed -n "$(($sl+3))"p ./gen.tmp >> 29291.txt	#Qeshm
	sed -n "$(($sl+4))"p ./gen.tmp >> 30580.txt	#Hormoz
	sed -n "$(($sl+5))"p ./gen.tmp >> 31116.txt	#St.III
	sed -n "$(($sl+6))"p ./gen.tmp >> 34978.txt	#Asaluyeh
	sed -n "$(($sl+7))"p ./gen.tmp >> 41647.txt	#St.II
	sed -n "$(($sl+8))"p ./gen.tmp >> 43903.txt	#Bushehr
	sed -n "$(($sl+9))"p ./gen.tmp >> 46435.txt	#St.I

	sed -n "$(($sl+10))"p ./gen.tmp >> 93457.txt	#St.VII
	sed -n "$(($sl+11))"p ./gen.tmp >> 100897.txt	#St.VI
	sed -n "$(($sl+12))"p ./gen.tmp >> 103856.txt	#St.V
	sed -n "$(($sl+13))"p ./gen.tmp >> 105365.txt	#Chabahar
	sed -n "$(($sl+14))"p ./gen.tmp >> 106090.txt	#Jask
	sl=$(($sl+15))
done

rm -fv gen.txt
date1=`sed -n 1p ../$dir/temp.txt`
date1=`date -d "$date1 -1 day" +%Y/%m/%d`
for j in {1..4}; do
	date1=`date -d "$date1 +1 day" +%Y/%m/%d`
	echo -e "$date1 \n\n" >> gen.txt
	for k in {03..21..03}; do
		echo -e "$k \n\n" >> gen.txt			
	done
done

echo "   Generating Time Series Plots for the Persian Gulf..."
for i in 43903 34978 28287 24149 29291 30580 23790 31116 41647 46435; do
	paste $i.txt gen.txt > $i.tmp
	rm $i.txt
done

cat points.dat.per | while read a b; do
	sed -i "22 s:.*:set output \"$a.ps\":" plot.gp.per
	sed -i "124 s:.*:set x2label \"$a\":" plot.gp.per
	sed -i "157 s/.*/plot \"$b.tmp\" u 1:xticlabel(2) w l ls 1 smooth csplines, \"\" u 1:xticlabel(2) w p ls 1/" plot.gp.per
	gnuplot ./plot.gp.per
	ps2pdf14 ./$a.ps ../$dir/$a.pdf
	mv ./$a.ps ../$dir/
done
pdftk ../$dir/*.pdf cat output ../$dir/persian_plot.pdf
echo 'Done!'
echo ' '
echo ' '

echo "   Generating Time Series Plots for the Indian Ocean..."
for i in 106090 105365 103856 100897 93457; do
	paste $i.txt gen.txt > $i.tmp
	rm $i.txt
done

cat points.dat.ind | while read a b; do
	sed -i "22 s:.*:set output \"$a.ps\":" plot.gp.ind
	sed -i "124 s:.*:set x2label \"$a\":" plot.gp.ind
	sed -i "157 s/.*/plot \"$b.tmp\" u 1:xticlabel(2) w l ls 1 smooth csplines, \"\" u 1:xticlabel(2) w p ls 1/" plot.gp.ind
	gnuplot ./plot.gp.ind
	ps2pdf14 ./$a.ps ../$dir/$a.pdf
	mv ./$a.ps ../$dir/
done

pdftk ../$dir/*.pdf cat output ../$dir/indian_plot.pdf
rm -fv ./ww3_outp.inp
echo 'Done!'
echo ' '
echo ' '
